package com.suresh.algorithms.sort.problemset.collinearpoints;

import java.util.ArrayList;
import java.util.List;

public class FastCollinearPoints {

  private Point[] copiedPointsArray;
  private List<LineSegment> segments;

  /**
   * constructor to compute collinear points.
   * 
   * @param points
   *          input points to compute collinear points.
   */
  public FastCollinearPoints(Point[] points) { // finds all line segments containing 4 or more
                                               // points
    if (points == null) {
      throw new java.lang.IllegalArgumentException();
    }
    copiedPointsArray = new Point[points.length];
    segments = new ArrayList<LineSegment>();
    for (int i = 0; i < points.length; i++) {
      if (points[i] == null) {
        throw new java.lang.IllegalArgumentException();
      }
      copiedPointsArray[i] = points[i];
    }

  }

  public int numberOfSegments() { // the number of line segments
    return 0;

  }

  public LineSegment[] segments() { // the line segments
    return null;
  }

}
